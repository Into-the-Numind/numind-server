package v1

import "numind-server/internal/pkg/model"

// LoginRequest 指定了 `POST /login` 接口的请求参数.
type LoginRequest struct {
	Username string `json:"username" valid:"alphanum,required,stringlength(1|255)"`
	Password string `json:"password" valid:"required,stringlength(6|18)"`
}

// LoginResponse 指定了 `POST /login` 接口的返回参数.
type LoginResponse struct {
	Token string `json:"token"`
}

// ChangePasswordRequest 指定了 `POST /v1/users/{name}/change-password` 接口的请求参数.
type ChangePasswordRequest struct {
	// 旧密码.
	OldPassword string `json:"oldPassword" valid:"required,stringlength(6|18)"`

	// 新密码.
	NewPassword string `json:"newPassword" valid:"required,stringlength(6|18)"`
}

// CreateUserRequest 指定了 `POST /v1/users` 接口的请求参数.
type CreateUserRequest struct {
	Username string `json:"username" valid:"alphanum,required,stringlength(1|255)"`
	Password string `json:"password" valid:"required,stringlength(6|18)"`
	Nickname string `json:"nickname" valid:"required,stringlength(1|255)"`
	Email    string `json:"email" valid:"required,email"`
	Phone    string `json:"phone" valid:"required,stringlength(11|11)"`
}

// GetUserResponse 指定了 `GET /v1/users/{name}` 接口的返回参数.
type GetUserResponse UserInfo

// UserInfo 指定了用户的详细信息.
type UserInfo struct {
	Username  string `json:"username"`
	Nickname  string `json:"nickname"`
	Email     string `json:"email"`
	Phone     string `json:"phone"`
	PostCount int64  `json:"postCount"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
}

// ListUserRequest 指定了 `GET /v1/users` 接口的请求参数.
type ListUserRequest struct {
	Offset int `form:"offset"`
	Limit  int `form:"limit"`
}

// ListUserResponse 指定了 `GET /v1/users` 接口的返回参数.
type ListUserResponse struct {
	TotalCount int64       `json:"totalCount"`
	Users      []*UserInfo `json:"users"`
}

// UpdateUserRequest 指定了 `PUT /v1/users/{name}` 接口的请求参数.
type UpdateUserRequest struct {
	Nickname *string `json:"nickname" valid:"stringlength(1|255)"`
	Email    *string `json:"email" valid:"email"`
	Phone    *string `json:"phone" valid:"stringlength(11|11)"`
}

// UpdateUserProfileRequest 指定了修改用户个人信息的请求参数
type UpdateUserProfileRequest struct {
	Nickname  *string `json:"nickname" valid:"stringlength(1|100)"`
	AvatarURL *string `json:"avatar_url" valid:"stringlength(1|512)"`
}

type WechatLoginRequest struct {
	Code      string `json:"code" binding:"required"`
	PhoneCode string `json:"phone_code"`
}

type WechatLoginResponse struct {
	AccessToken string      `json:"access_token"`
	TokenType   string      `json:"token_type"`
	User        *model.User `json:"user"`
}

// WebLoginRequest Web端用户名密码登录请求
type WebLoginRequest struct {
	Username string `json:"username" binding:"required"`
	Password string `json:"password" binding:"required"`
}

// WebLoginResponse Web端登录响应
type WebLoginResponse struct {
	AccessToken string      `json:"access_token"`
	TokenType   string      `json:"token_type"`
	User        *model.User `json:"user"`
}

// CreateFeedbackRequest 创建反馈的请求参数
type CreateFeedbackRequest struct {
	Content string `json:"content" binding:"required" valid:"required,stringlength(1|1000)"`
	Type    string `json:"type"`
}

// FeedbackResponse 反馈的响应参数
type FeedbackResponse struct {
	ID        uint      `json:"id"`
	UserID    uint      `json:"user_id"`
	Content   string    `json:"content"`
	Type      string    `json:"type"`
	Status    int       `json:"status"`
	Reply     string    `json:"reply"`
	CreatedAt string    `json:"created_at"`
	UpdatedAt string    `json:"updated_at"`
	User      *UserInfo `json:"user,omitempty"`
}

// ListFeedbackResponse 反馈列表的响应参数
type ListFeedbackResponse struct {
	TotalCount int64               `json:"total_count"`
	Feedbacks  []*FeedbackResponse `json:"feedbacks"`
}

// CreateTemplateRequest 创建模板的请求参数
type CreateTemplateRequest struct {
	Name         string `json:"name" binding:"required" valid:"required,stringlength(1|50)"`
	File         string `json:"file" binding:"required" valid:"required"`
	Preview      string `json:"preview"`        // 预览图片路径
	IsMemberOnly bool   `json:"is_member_only"` // 是否仅会员可用
}

// UpdateTemplateRequest 更新模板的请求参数
type UpdateTemplateRequest struct {
	Name         *string `json:"name" valid:"stringlength(1|50)"`
	File         *string `json:"file"`
	Preview      *string `json:"preview"`        // 预览图片路径
	IsMemberOnly *bool   `json:"is_member_only"` // 是否仅会员可用
}

// TemplateResponse 模板的响应参数
type TemplateResponse struct {
	ID           uint   `json:"id"`
	Name         string `json:"name"`
	File         string `json:"file"`
	Preview      string `json:"preview"`        // 预览图片路径
	IsMemberOnly bool   `json:"is_member_only"` // 是否仅会员可用
	CreatedAt    string `json:"created_at"`
	UpdatedAt    string `json:"updated_at"`
}

// ListTemplateResponse 模板列表的响应参数
type ListTemplateResponse struct {
	TotalCount int64               `json:"total_count"`
	Templates  []*TemplateResponse `json:"templates"`
}

// CreateCategoryRequest 创建分类的请求参数
type CreateCategoryRequest struct {
	Name  string `json:"name" binding:"required" valid:"required,stringlength(1|50)"`
	Color string `json:"color" valid:"stringlength(1|20)"`
	Sort  int    `json:"sort"`
}

// UpdateCategoryRequest 更新分类的请求参数
type UpdateCategoryRequest struct {
	Name  *string `json:"name" valid:"stringlength(1|50)"`
	Color *string `json:"color" valid:"stringlength(1|20)"`
	Sort  *int    `json:"sort"`
}

// CategoryResponse 分类的响应参数
type CategoryResponse struct {
	ID        uint   `json:"id"`
	UserID    uint   `json:"user_id"`
	Name      string `json:"name"`
	Color     string `json:"color"`
	Sort      int    `json:"sort"`
	CreatedAt string `json:"created_at"`
	UpdatedAt string `json:"updated_at"`
}

// ListCategoryResponse 分类列表的响应参数
type ListCategoryResponse struct {
	TotalCount int64               `json:"total_count"`
	Categories []*CategoryResponse `json:"categories"`
}
